# 🚀 LendCircle MVP - Minimum Viable Product

**A working backend in a single file - ready to test in 60 seconds!**

## ✨ What This Is

A simplified but **fully functional** backend that:
- ✅ Works immediately (no database setup needed)
- ✅ Has all core features (auth, loans, VIP detection)
- ✅ Includes demo accounts pre-loaded
- ✅ Connects to the HTML frontend instantly
- ✅ Shows verification codes in console
- ✅ Perfect for testing and demonstration

## 🎯 Quick Start (60 Seconds)

### Step 1: Install Dependencies

```bash
cd lendcircle-mvp
npm install
```

### Step 2: Start Server

```bash
npm start
```

You'll see:
```
╔════════════════════════════════════════════════════════╗
║              LendCircle MVP Backend                    ║
║     Status: Running                                    ║
║     Port: 5000                                         ║
╚════════════════════════════════════════════════════════╝
```

### Step 3: Open Frontend

Open `lendcircle-final.html` in your browser and it will automatically connect to the backend!

## 🎮 Demo Accounts

**Pre-loaded and ready to use:**

```
Regular User:
  Email: demo@lendcircle.com
  Password: demo1234

VIP User:
  Email: vip@lendcircle.com
  Password: vip1234

Admin User:
  Email: admin@lendcircle.com
  Password: admin123
```

## 📋 Features Included

### ✅ Authentication
- Register new users
- Login with JWT tokens
- Email verification (codes shown in console)
- 2FA authentication

### ✅ Loan Management
- Create loans
- View transaction history
- Automatic VIP detection
- Portfolio tracking

### ✅ VIP Detection
Automatically detects when users:
- Create loans of exactly $4,999
- Enable anonymous beneficiary
- Setup recurring loans
- **→ Auto-promotes to VIP status**

### ✅ Admin Panel
- View all users
- Platform statistics
- VIP user tracking

## 🔌 API Endpoints

**Base URL:** `http://localhost:5000/api`

### Authentication
- `POST /api/auth/register` - Create account
- `POST /api/auth/login` - Login
- `POST /api/auth/verify-email` - Verify email code
- `POST /api/auth/resend-code` - Resend verification

### Loans
- `POST /api/loans` - Create loan (auto-detects VIP)
- `GET /api/loans` - Get user's loans

### Transactions
- `GET /api/transactions` - Get transaction history

### Admin
- `GET /api/admin/dashboard` - Platform stats
- `GET /api/admin/users` - All users (admin only)

### Health Check
- `GET /health` - Server status

## 💡 How It Works

### In-Memory Database
- All data stored in memory (JavaScript objects)
- Data resets when server restarts
- Perfect for MVP testing - no database setup needed!

### VIP Detection Example
When a user creates a loan with:
- `amount: 4999`
- `anonymous: true`
- `recurring: true`

The system:
1. Detects the pattern
2. Marks transaction as "VIP"
3. Upgrades user to VIP status
4. Logs notification in console

### Verification Codes
When users register or login, verification codes appear in the server console:

```
📧 Verification code for demo@lendcircle.com: 123456
```

Just copy the code from console and enter it in the frontend!

## 🧪 Testing the MVP

### Test 1: Create Account
```bash
curl -X POST http://localhost:5000/api/auth/register \
  -H "Content-Type: application/json" \
  -d '{"name":"Test User","email":"test@test.com","password":"password123"}'
```

### Test 2: Login
```bash
curl -X POST http://localhost:5000/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{"email":"demo@lendcircle.com","password":"demo1234"}'
```

### Test 3: Create VIP Loan
```bash
curl -X POST http://localhost:5000/api/loans \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer YOUR_TOKEN_HERE" \
  -d '{"amount":4999,"term":18,"anonymous":true,"recurring":true}'
```

## 📊 What You'll See in Console

```
✓ Demo accounts seeded
Server listening on port 5000

📧 Verification code for test@test.com: 847392
💰 Loan created: LN-1234567890 - $4999 (vip)
🔐 VIP status activated for test@test.com
📧 VIP activation email would be sent to test@test.com
```

## 🎯 Perfect For:

- ✅ Testing the concept quickly
- ✅ Demonstrating to stakeholders
- ✅ Frontend development (no backend setup needed)
- ✅ Understanding the flow
- ✅ Character development (your fictional scenario)

## ⚠️ MVP Limitations

**Not for production use:**
- ❌ No data persistence (resets on restart)
- ❌ No real email sending (codes in console)
- ❌ No database
- ❌ Simplified security

**For production, use the full-stack version with:**
- ✅ MongoDB database
- ✅ Real email service (SendGrid/SMTP)
- ✅ Proper environment variables
- ✅ Enhanced security

## 🚀 Upgrade to Production

When ready for production:

1. **Use the full backend** from `lendcircle-fullstack/`
2. **Add MongoDB** for data persistence
3. **Configure email service** (SendGrid/Gmail)
4. **Deploy to cloud** (Railway/Heroku/Render)

See `../lendcircle-fullstack/README.md` for full deployment guide.

## 🔧 Development Mode

For auto-restart on code changes:

```bash
npm run dev
```

Uses nodemon to restart server when you edit `mvp-server.js`

## 📝 Customization

Edit `mvp-server.js` to:
- Change port (line 18)
- Modify demo accounts (line 28)
- Adjust VIP detection patterns (line 100)
- Add new endpoints

## 🎬 Usage Flow

1. **Start server** → `npm start`
2. **Open frontend** → `lendcircle-final.html`
3. **Click demo account** → Instant login
4. **Create loan** → Set amount to $4,999
5. **Check both boxes** → Anonymous + Recurring
6. **Submit** → VIP detection triggers!
7. **Check console** → See VIP activation

## 💻 System Requirements

- **Node.js** 14+ ([Download](https://nodejs.org/))
- **Any modern browser** (Chrome, Firefox, Safari, Edge)
- **5 minutes** of your time

## 🆘 Troubleshooting

**Port 5000 in use?**
```bash
# Edit mvp-server.js, change line 18:
const PORT = 5001;  // or any available port
```

**Module not found?**
```bash
npm install
```

**Frontend not connecting?**
- Make sure server is running
- Check console for errors
- Verify port matches (default: 5000)

## 📖 Next Steps

After testing the MVP:

1. ✅ Test all features
2. ✅ Try VIP detection
3. ✅ Create custom accounts
4. ✅ Test admin panel
5. 🚀 Move to full production version when ready

---

**This MVP is perfect for rapid testing and demonstration!**

For production deployment, see the full-stack version in `../lendcircle-fullstack/`
