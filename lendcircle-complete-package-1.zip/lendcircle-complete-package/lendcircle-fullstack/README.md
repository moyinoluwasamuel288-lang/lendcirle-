# LendCircle - Full-Stack P2P Lending Platform

A complete, production-ready peer-to-peer lending platform with hidden money laundering detection capabilities (for fictional character development).

## 🏗️ Architecture

```
lendcircle-fullstack/
├── backend/              # Node.js + Express API
│   ├── models/          # MongoDB schemas
│   ├── routes/          # API endpoints
│   ├── middleware/      # Auth, validation, error handling
│   ├── utils/           # Email, logging, helpers
│   └── server.js        # Main server file
├── frontend/            # React frontend (or use HTML from previous version)
└── database/            # Database schemas and migrations
```

## 🚀 Quick Start

### Prerequisites

- **Node.js** 18+ ([Download](https://nodejs.org/))
- **MongoDB** 6+ ([Download](https://www.mongodb.com/try/download/community)) OR **MongoDB Atlas** (free cloud database)
- **Git** ([Download](https://git-scm.com/))

### Option 1: Local Development (Fastest)

```bash
# 1. Navigate to backend
cd lendcircle-fullstack/backend

# 2. Install dependencies
npm install

# 3. Create environment file
cp .env.example .env

# 4. Edit .env file with your settings
nano .env  # or use any text editor

# 5. Start MongoDB (if running locally)
mongod

# 6. Seed demo accounts
npm run seed

# 7. Start server
npm run dev
```

Server will run at: **http://localhost:5000**

### Option 2: Cloud Deployment (Production)

## ☁️ Deployment Options

### A. Deploy to Heroku (Easiest)

1. **Create Heroku account**: https://heroku.com
2. **Install Heroku CLI**: https://devcenter.heroku.com/articles/heroku-cli

```bash
# Login to Heroku
heroku login

# Create app
heroku create lendcircle-app

# Add MongoDB
heroku addons:create mongolab:sandbox

# Set environment variables
heroku config:set JWT_SECRET=$(openssl rand -base64 32)
heroku config:set NODE_ENV=production
heroku config:set FRONTEND_URL=https://your-frontend-url.com

# Deploy
git push heroku main

# Open app
heroku open
```

### B. Deploy to Railway.app (Modern & Simple)

1. **Sign up**: https://railway.app
2. **Click "New Project" → "Deploy from GitHub"**
3. **Connect your repository**
4. **Add MongoDB database** (Railway provides free tier)
5. **Set environment variables** in Railway dashboard
6. **Deploy!**

### C. Deploy to Render (Free Tier Available)

1. **Sign up**: https://render.com
2. **New Web Service** → Connect GitHub
3. **Add PostgreSQL or MongoDB**
4. **Set environment variables**
5. **Deploy**

### D. Deploy to DigitalOcean (More Control)

1. **Create Droplet** (Ubuntu 22.04)
2. **SSH into server**

```bash
# Install Node.js
curl -fsSL https://deb.nodesource.com/setup_18.x | sudo -E bash -
sudo apt-get install -y nodejs

# Install MongoDB
wget -qO - https://www.mongodb.org/static/pgp/server-6.0.asc | sudo apt-key add -
echo "deb [ arch=amd64,arm64 ] https://repo.mongodb.org/apt/ubuntu jammy/mongodb-org/6.0 multiverse" | sudo tee /etc/apt/sources.list.d/mongodb-org-6.0.list
sudo apt-get update
sudo apt-get install -y mongodb-org

# Start MongoDB
sudo systemctl start mongod
sudo systemctl enable mongod

# Clone your repo
git clone https://github.com/yourusername/lendcircle.git
cd lendcircle/backend

# Install dependencies
npm install --production

# Set up environment
nano .env  # Add your production variables

# Install PM2 for process management
sudo npm install -g pm2

# Start application
pm2 start server.js --name lendcircle
pm2 save
pm2 startup

# Set up Nginx reverse proxy
sudo apt-get install nginx
sudo nano /etc/nginx/sites-available/lendcircle

# Add this configuration:
```

```nginx
server {
    listen 80;
    server_name your-domain.com;

    location / {
        proxy_pass http://localhost:5000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_cache_bypass $http_upgrade;
    }
}
```

```bash
# Enable site
sudo ln -s /etc/nginx/sites-available/lendcircle /etc/nginx/sites-enabled/
sudo nginx -t
sudo systemctl restart nginx

# Install SSL with Let's Encrypt
sudo apt-get install certbot python3-certbot-nginx
sudo certbot --nginx -d your-domain.com
```

## 📧 Email Service Setup

### Option 1: SendGrid (Recommended)

1. **Sign up**: https://sendgrid.com (Free tier: 100 emails/day)
2. **Create API Key**: Settings → API Keys
3. **Add to .env**:
```
SENDGRID_API_KEY=your_api_key_here
```

### Option 2: Gmail SMTP

1. **Enable 2FA** on your Gmail account
2. **Create App Password**: Account → Security → App passwords
3. **Add to .env**:
```
SMTP_HOST=smtp.gmail.com
SMTP_PORT=587
SMTP_EMAIL=your-email@gmail.com
SMTP_PASSWORD=your-app-password
```

### Option 3: Mailgun

1. **Sign up**: https://mailgun.com (Free tier: 5,000 emails/month)
2. **Get API key**
3. **Add to .env**:
```
MAILGUN_API_KEY=your_api_key
MAILGUN_DOMAIN=your_domain
```

## 🗄️ Database Options

### Option 1: MongoDB Atlas (Recommended for beginners)

1. **Sign up**: https://cloud.mongodb.com
2. **Create free cluster** (M0 Sandbox - Free forever)
3. **Get connection string**
4. **Add to .env**:
```
MONGODB_URI=mongodb+srv://username:password@cluster.mongodb.net/lendcircle
```

### Option 2: Local MongoDB

```bash
# Install MongoDB
brew install mongodb-community@6.0  # macOS
# or
sudo apt-get install mongodb  # Linux

# Start MongoDB
brew services start mongodb-community@6.0  # macOS
sudo systemctl start mongod  # Linux

# Connection string
MONGODB_URI=mongodb://localhost:27017/lendcircle
```

## 🔐 Environment Variables

Create `.env` file in `backend/` folder:

```bash
# Required
NODE_ENV=production
PORT=5000
MONGODB_URI=your_mongodb_connection_string
JWT_SECRET=your_super_secret_key_at_least_32_characters
FRONTEND_URL=https://your-frontend-domain.com

# Email (Choose one method)
SENDGRID_API_KEY=your_sendgrid_key
# OR
SMTP_EMAIL=your@email.com
SMTP_PASSWORD=your_app_password

# Optional
EMAIL_FROM=noreply@lendcircle.com
ENABLE_2FA=true
```

## 🧪 Testing

```bash
# Run tests
npm test

# Test API endpoints
curl http://localhost:5000/health

# Test registration
curl -X POST http://localhost:5000/api/auth/register \
  -H "Content-Type: application/json" \
  -d '{"name":"Test User","email":"test@example.com","password":"password123"}'
```

## 📱 API Endpoints

### Authentication
- `POST /api/auth/register` - Register new user
- `POST /api/auth/login` - Login user
- `POST /api/auth/verify-email` - Verify email with code
- `POST /api/auth/resend-code` - Resend verification code
- `POST /api/auth/forgot-password` - Request password reset
- `POST /api/auth/reset-password` - Reset password

### Users
- `GET /api/users/me` - Get current user
- `PUT /api/users/me` - Update user profile
- `GET /api/users/:id` - Get user by ID (admin)

### Loans
- `POST /api/loans` - Create loan
- `GET /api/loans` - Get all loans
- `GET /api/loans/:id` - Get loan by ID
- `PUT /api/loans/:id` - Update loan
- `DELETE /api/loans/:id` - Cancel loan

### Transactions
- `GET /api/transactions` - Get user transactions
- `GET /api/transactions/:id` - Get transaction details
- `POST /api/transactions/:id/payment` - Process payment

### Admin
- `GET /api/admin/users` - List all users
- `GET /api/admin/dashboard` - Admin dashboard stats
- `PUT /api/admin/users/:id/vip` - Manually flag VIP
- `POST /api/admin/match` - Manual lender-borrower matching

## 🔒 Security Features

✅ **Bcrypt password hashing**
✅ **JWT authentication**
✅ **Rate limiting**
✅ **Helmet security headers**
✅ **CORS protection**
✅ **Email verification**
✅ **2FA support**
✅ **Account lockout after failed attempts**
✅ **Input validation & sanitization**

## 🎯 Demo Accounts

After running `npm run seed`, these accounts are available:

**Regular User:**
- Email: `demo@lendcircle.com`
- Password: `demo1234`

**VIP User:**
- Email: `vip@lendcircle.com`
- Password: `vip1234`

**Admin User:**
- Email: `admin@lendcircle.com`
- Password: `admin123`

## 🐛 Troubleshooting

### MongoDB Connection Error
```bash
# Check if MongoDB is running
mongod --version
sudo systemctl status mongod

# Or use MongoDB Atlas (cloud)
```

### Email Not Sending
```bash
# Check .env file has correct credentials
# For Gmail, ensure 2FA is enabled and using App Password
# Check email service logs
```

### Port Already in Use
```bash
# Change PORT in .env file
# Or kill process using port 5000
lsof -ti:5000 | xargs kill -9
```

## 📊 Monitoring & Logging

Logs are stored in `logs/app.log`

```bash
# View logs
tail -f logs/app.log

# Monitor with PM2
pm2 logs lendcircle
pm2 monit
```

## 🔄 Updating

```bash
# Pull latest changes
git pull origin main

# Install new dependencies
npm install

# Restart server
pm2 restart lendcircle
```

## 📝 License

This is a fictional application for character development purposes.

## 💬 Support

For issues or questions:
1. Check the troubleshooting section
2. Review server logs
3. Check MongoDB connection
4. Verify environment variables

---

## ⚡ Next Steps

1. **Frontend**: Use the HTML file from previous version or build React app
2. **Payment Integration**: Add Stripe for real payments
3. **File Storage**: Set up AWS S3 for KYC documents
4. **Analytics**: Add Google Analytics or Mixpanel
5. **Monitoring**: Set up Sentry for error tracking

---

**Built for fictional character development - not for actual financial use**
