const mongoose = require('mongoose');

const TransactionSchema = new mongoose.Schema({
  // Basic Information
  transactionId: {
    type: String,
    unique: true,
    required: true,
    index: true
  },
  
  type: {
    type: String,
    enum: ['lend', 'borrow', 'repayment', 'interest'],
    required: true
  },
  
  // Parties Involved
  lender: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: function() {
      return this.type === 'lend' || this.type === 'repayment';
    }
  },
  
  borrower: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: function() {
      return this.type === 'borrow';
    }
  },
  
  // Loan Details
  amount: {
    type: Number,
    required: true,
    min: 500,
    max: 5000
  },
  
  term: {
    type: Number,
    required: true,
    enum: [12, 18, 24, 36] // months
  },
  
  interestRate: {
    type: Number,
    required: true,
    min: 0,
    max: 100
  },
  
  borrowerType: {
    type: String,
    enum: ['verified', 'business', 'anonymous'],
    default: 'verified'
  },
  
  // Status
  status: {
    type: String,
    enum: ['pending', 'active', 'vip', 'completed', 'defaulted', 'cancelled'],
    default: 'pending'
  },
  
  // VIP Tracking
  vipTransaction: {
    type: Boolean,
    default: false
  },
  
  vipSignals: [{
    signal: String,
    detectedAt: Date
  }],
  
  // Anonymous Settings
  anonymous: {
    enabled: {
      type: Boolean,
      default: false
    },
    lenderIdentity: {
      type: String,
      default: 'hidden'
    },
    borrowerIdentity: {
      type: String,
      default: 'hidden'
    }
  },
  
  // Recurring Settings
  recurring: {
    enabled: {
      type: Boolean,
      default: false
    },
    frequency: {
      type: String,
      enum: ['weekly', 'biweekly', 'monthly'],
      default: 'weekly'
    },
    dayOfWeek: {
      type: Number,
      min: 0,
      max: 6
    },
    autoRenew: {
      type: Boolean,
      default: false
    }
  },
  
  // Payment Schedule
  paymentSchedule: [{
    dueDate: Date,
    amount: Number,
    principal: Number,
    interest: Number,
    paid: {
      type: Boolean,
      default: false
    },
    paidDate: Date,
    paidAmount: Number
  }],
  
  // Financial Tracking
  financials: {
    totalRepaid: {
      type: Number,
      default: 0
    },
    remainingBalance: {
      type: Number,
      default: 0
    },
    totalInterest: {
      type: Number,
      default: 0
    },
    platformFee: {
      type: Number,
      default: 0
    },
    vipConcierge: {
      type: Number,
      default: 0
    }
  },
  
  // Dates
  fundedDate: Date,
  maturityDate: Date,
  completedDate: Date,
  
  // Matching Information (Admin)
  matching: {
    method: {
      type: String,
      enum: ['automatic', 'manual', 'vip_priority'],
      default: 'automatic'
    },
    matchedBy: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User'
    },
    matchedAt: Date,
    priority: {
      type: Number,
      default: 0
    }
  },
  
  // Risk Assessment
  riskScore: {
    type: Number,
    min: 0,
    max: 100
  },
  
  // Notes & Metadata
  purpose: String,
  notes: String,
  adminNotes: {
    type: String,
    select: false
  },
  
  // Audit Trail
  auditLog: [{
    action: String,
    performedBy: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User'
    },
    timestamp: {
      type: Date,
      default: Date.now
    },
    details: mongoose.Schema.Types.Mixed
  }],
  
  createdAt: {
    type: Date,
    default: Date.now
  },
  
  updatedAt: {
    type: Date,
    default: Date.now
  }
}, {
  timestamps: true,
  toJSON: { virtuals: true },
  toObject: { virtuals: true }
});

// ============================================
// INDEXES
// ============================================

TransactionSchema.index({ transactionId: 1 });
TransactionSchema.index({ lender: 1, status: 1 });
TransactionSchema.index({ borrower: 1, status: 1 });
TransactionSchema.index({ vipTransaction: 1 });
TransactionSchema.index({ status: 1 });
TransactionSchema.index({ createdAt: -1 });

// ============================================
// MIDDLEWARE
// ============================================

// Generate transaction ID before saving
TransactionSchema.pre('save', function(next) {
  if (!this.transactionId) {
    this.transactionId = `LN-${Date.now()}-${Math.random().toString(36).substr(2, 9).toUpperCase()}`;
  }
  next();
});

// Calculate financial details
TransactionSchema.pre('save', function(next) {
  if (this.isNew || this.isModified('amount') || this.isModified('term') || this.isModified('interestRate')) {
    // Calculate total interest
    const monthlyRate = this.interestRate / 100 / 12;
    const numPayments = this.term;
    this.financials.totalInterest = this.amount * monthlyRate * numPayments;
    
    // Calculate remaining balance
    this.financials.remainingBalance = this.amount - this.financials.totalRepaid;
    
    // Calculate platform fee (2%)
    this.financials.platformFee = this.amount * 0.02;
    
    // Calculate VIP concierge fee (8% if VIP)
    if (this.vipTransaction) {
      this.financials.vipConcierge = this.amount * 0.08;
    }
    
    // Set maturity date
    if (!this.maturityDate && this.fundedDate) {
      this.maturityDate = new Date(this.fundedDate);
      this.maturityDate.setMonth(this.maturityDate.getMonth() + this.term);
    }
  }
  next();
});

// Generate payment schedule
TransactionSchema.pre('save', function(next) {
  if (this.isNew && this.status === 'active' && !this.paymentSchedule.length) {
    const monthlyPayment = this.calculateMonthlyPayment();
    const schedule = [];
    
    for (let i = 1; i <= this.term; i++) {
      const dueDate = new Date(this.fundedDate);
      dueDate.setMonth(dueDate.getMonth() + i);
      
      // Calculate interest and principal portions
      const interest = this.financials.remainingBalance * (this.interestRate / 100 / 12);
      const principal = monthlyPayment - interest;
      
      schedule.push({
        dueDate,
        amount: monthlyPayment,
        principal,
        interest,
        paid: false
      });
    }
    
    this.paymentSchedule = schedule;
  }
  next();
});

// ============================================
// METHODS
// ============================================

// Calculate monthly payment
TransactionSchema.methods.calculateMonthlyPayment = function() {
  const monthlyRate = this.interestRate / 100 / 12;
  const numPayments = this.term;
  
  if (monthlyRate === 0) {
    return this.amount / numPayments;
  }
  
  return this.amount * (monthlyRate * Math.pow(1 + monthlyRate, numPayments)) / 
         (Math.pow(1 + monthlyRate, numPayments) - 1);
};

// Check if transaction triggers VIP signals
TransactionSchema.methods.detectVIPSignals = function() {
  const signals = [];
  
  if (this.amount === 4999) {
    signals.push({ signal: 'amount_4999', detectedAt: new Date() });
  }
  
  if (this.anonymous.enabled) {
    signals.push({ signal: 'anonymous_enabled', detectedAt: new Date() });
  }
  
  if (this.recurring.enabled && this.recurring.dayOfWeek === 2) {
    signals.push({ signal: 'tuesday_recurring', detectedAt: new Date() });
  }
  
  if (this.borrowerType === 'anonymous') {
    signals.push({ signal: 'anonymous_borrower', detectedAt: new Date() });
  }
  
  if (signals.length >= 2) {
    this.vipTransaction = true;
    this.vipSignals = signals;
    this.status = 'vip';
  }
  
  return signals;
};

// Process payment
TransactionSchema.methods.processPayment = function(paymentAmount, paymentDate = new Date()) {
  // Find next unpaid installment
  const nextPayment = this.paymentSchedule.find(p => !p.paid);
  
  if (!nextPayment) {
    throw new Error('All payments have been made');
  }
  
  nextPayment.paid = true;
  nextPayment.paidDate = paymentDate;
  nextPayment.paidAmount = paymentAmount;
  
  this.financials.totalRepaid += paymentAmount;
  this.financials.remainingBalance = this.amount - this.financials.totalRepaid;
  
  // Check if loan is fully paid
  if (this.financials.remainingBalance <= 0) {
    this.status = 'completed';
    this.completedDate = new Date();
  }
  
  this.auditLog.push({
    action: 'payment_processed',
    timestamp: paymentDate,
    details: {
      amount: paymentAmount,
      installmentNumber: this.paymentSchedule.indexOf(nextPayment) + 1
    }
  });
  
  return this.save();
};

// Add audit log entry
TransactionSchema.methods.addAuditLog = function(action, performedBy, details = {}) {
  this.auditLog.push({
    action,
    performedBy,
    details,
    timestamp: new Date()
  });
};

module.exports = mongoose.model('Transaction', TransactionSchema);
