const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const validator = require('validator');

const UserSchema = new mongoose.Schema({
  // Basic Information
  name: {
    type: String,
    required: [true, 'Please provide a name'],
    trim: true,
    maxlength: [100, 'Name cannot exceed 100 characters']
  },
  
  email: {
    type: String,
    required: [true, 'Please provide an email'],
    unique: true,
    lowercase: true,
    validate: [validator.isEmail, 'Please provide a valid email'],
    index: true
  },
  
  password: {
    type: String,
    required: [true, 'Please provide a password'],
    minlength: [8, 'Password must be at least 8 characters'],
    select: false // Don't return password in queries by default
  },
  
  // User Status
  role: {
    type: String,
    enum: ['user', 'vip', 'admin'],
    default: 'user'
  },
  
  verified: {
    type: Boolean,
    default: false
  },
  
  active: {
    type: Boolean,
    default: true
  },
  
  // KYC Information
  kyc: {
    status: {
      type: String,
      enum: ['none', 'pending', 'verified', 'rejected'],
      default: 'none'
    },
    documents: [{
      type: {
        type: String,
        enum: ['id', 'passport', 'proof_of_address']
      },
      url: String,
      uploadedAt: Date,
      status: {
        type: String,
        enum: ['pending', 'approved', 'rejected'],
        default: 'pending'
      }
    }],
    ssn: {
      type: String,
      select: false // Never return SSN in queries
    },
    dateOfBirth: Date,
    address: {
      street: String,
      city: String,
      state: String,
      zipCode: String,
      country: String
    },
    verifiedAt: Date
  },
  
  // VIP Status Tracking
  vipStatus: {
    isVip: {
      type: Boolean,
      default: false
    },
    detectedAt: Date,
    signalCount: {
      type: Number,
      default: 0
    },
    patterns: [{
      type: String,
      detectedAt: Date
    }],
    contactedVia: String, // 'signal', 'telegram', etc.
    encryptedContactInfo: String
  },
  
  // 2FA
  twoFactorAuth: {
    enabled: {
      type: Boolean,
      default: false
    },
    secret: String,
    backupCodes: [String]
  },
  
  // Verification
  verificationCode: String,
  verificationCodeExpire: Date,
  
  resetPasswordToken: String,
  resetPasswordExpire: Date,
  
  // Portfolio & Statistics
  portfolio: {
    totalLent: {
      type: Number,
      default: 0
    },
    totalBorrowed: {
      type: Number,
      default: 0
    },
    activeLoans: {
      type: Number,
      default: 0
    },
    completedLoans: {
      type: Number,
      default: 0
    },
    averageReturn: {
      type: Number,
      default: 0
    }
  },
  
  // Activity Tracking
  lastLogin: Date,
  loginAttempts: {
    type: Number,
    default: 0
  },
  lockUntil: Date,
  
  // Metadata
  createdAt: {
    type: Date,
    default: Date.now
  },
  updatedAt: {
    type: Date,
    default: Date.now
  }
}, {
  timestamps: true,
  toJSON: { virtuals: true },
  toObject: { virtuals: true }
});

// ============================================
// INDEXES
// ============================================

UserSchema.index({ email: 1 });
UserSchema.index({ 'vipStatus.isVip': 1 });
UserSchema.index({ role: 1 });
UserSchema.index({ verified: 1 });

// ============================================
// MIDDLEWARE
// ============================================

// Hash password before saving
UserSchema.pre('save', async function(next) {
  if (!this.isModified('password')) {
    return next();
  }
  
  const salt = await bcrypt.genSalt(10);
  this.password = await bcrypt.hash(this.password, salt);
  next();
});

// Update timestamp
UserSchema.pre('save', function(next) {
  this.updatedAt = Date.now();
  next();
});

// ============================================
// METHODS
// ============================================

// Match password
UserSchema.methods.matchPassword = async function(enteredPassword) {
  return await bcrypt.compare(enteredPassword, this.password);
};

// Generate JWT token
UserSchema.methods.getSignedJwtToken = function() {
  return jwt.sign(
    { 
      id: this._id, 
      email: this.email,
      role: this.role 
    },
    process.env.JWT_SECRET,
    { expiresIn: process.env.JWT_EXPIRE }
  );
};

// Generate verification code
UserSchema.methods.generateVerificationCode = function() {
  const code = Math.floor(100000 + Math.random() * 900000).toString();
  this.verificationCode = code;
  this.verificationCodeExpire = Date.now() + 10 * 60 * 1000; // 10 minutes
  return code;
};

// Check if account is locked
UserSchema.methods.isLocked = function() {
  return !!(this.lockUntil && this.lockUntil > Date.now());
};

// Increment login attempts
UserSchema.methods.incrementLoginAttempts = function() {
  // Reset attempts if lock has expired
  if (this.lockUntil && this.lockUntil < Date.now()) {
    return this.updateOne({
      $set: { loginAttempts: 1 },
      $unset: { lockUntil: 1 }
    });
  }
  
  // Increment attempts
  const updates = { $inc: { loginAttempts: 1 } };
  
  // Lock account after 5 failed attempts
  if (this.loginAttempts + 1 >= 5 && !this.isLocked()) {
    updates.$set = { lockUntil: Date.now() + 2 * 60 * 60 * 1000 }; // 2 hours
  }
  
  return this.updateOne(updates);
};

// Reset login attempts
UserSchema.methods.resetLoginAttempts = function() {
  return this.updateOne({
    $set: { loginAttempts: 0 },
    $unset: { lockUntil: 1 }
  });
};

// Check VIP pattern
UserSchema.methods.checkVIPPattern = function(loanData) {
  const signals = [];
  
  // Pattern 1: $4,999 loans
  if (loanData.amount === 4999) {
    signals.push('amount_4999');
  }
  
  // Pattern 2: Anonymous beneficiary
  if (loanData.borrowerType === 'anonymous') {
    signals.push('anonymous_beneficiary');
  }
  
  // Pattern 3: Recurring patterns
  if (loanData.recurring) {
    signals.push('recurring_setup');
  }
  
  // Pattern 4: Tuesday pattern
  if (loanData.dayOfWeek === 2) {
    signals.push('tuesday_pattern');
  }
  
  // Update VIP status if multiple signals detected
  if (signals.length >= 2) {
    this.vipStatus.signalCount += 1;
    this.vipStatus.patterns.push({
      type: signals.join(','),
      detectedAt: new Date()
    });
    
    // Auto-flag as VIP after 3 signal occurrences
    if (this.vipStatus.signalCount >= 3 && !this.vipStatus.isVip) {
      this.vipStatus.isVip = true;
      this.vipStatus.detectedAt = new Date();
      this.role = 'vip';
    }
  }
  
  return signals.length >= 2;
};

// ============================================
// VIRTUAL FIELDS
// ============================================

UserSchema.virtual('transactions', {
  ref: 'Transaction',
  localField: '_id',
  foreignField: 'user'
});

module.exports = mongoose.model('User', UserSchema);
