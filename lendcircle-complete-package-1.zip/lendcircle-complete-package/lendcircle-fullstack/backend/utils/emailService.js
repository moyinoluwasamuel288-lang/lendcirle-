const nodemailer = require('nodemailer');
const logger = require('./logger');

// ============================================
// EMAIL SERVICE CONFIGURATION
// ============================================

class EmailService {
  constructor() {
    this.transporter = this.createTransporter();
  }

  createTransporter() {
    // Check if using SendGrid
    if (process.env.SENDGRID_API_KEY) {
      return nodemailer.createTransporter({
        host: 'smtp.sendgrid.net',
        port: 587,
        auth: {
          user: 'apikey',
          pass: process.env.SENDGRID_API_KEY
        }
      });
    }
    
    // Otherwise use SMTP
    return nodemailer.createTransporter({
      host: process.env.SMTP_HOST || 'smtp.gmail.com',
      port: process.env.SMTP_PORT || 587,
      secure: false,
      auth: {
        user: process.env.SMTP_EMAIL,
        pass: process.env.SMTP_PASSWORD
      }
    });
  }

  // ============================================
  // SEND EMAIL FUNCTION
  // ============================================

  async sendEmail(options) {
    try {
      const mailOptions = {
        from: process.env.EMAIL_FROM || 'LendCircle <noreply@lendcircle.com>',
        to: options.to,
        subject: options.subject,
        html: options.html,
        text: options.text
      };

      const info = await this.transporter.sendMail(mailOptions);
      logger.info(`Email sent successfully to ${options.to}`);
      return info;
    } catch (error) {
      logger.error('Email sending failed:', error);
      throw error;
    }
  }

  // ============================================
  // VERIFICATION EMAIL
  // ============================================

  async sendVerificationEmail(email, name, code) {
    const html = `
<!DOCTYPE html>
<html>
<head>
  <style>
    body {
      font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
      line-height: 1.6;
      color: #333;
      max-width: 600px;
      margin: 0 auto;
      padding: 20px;
    }
    .header {
      background: linear-gradient(135deg, #EC4899, #8B5CF6);
      color: white;
      padding: 30px;
      text-align: center;
      border-radius: 10px 10px 0 0;
    }
    .content {
      background: #f9f9f9;
      padding: 30px;
      border-radius: 0 0 10px 10px;
    }
    .code-box {
      background: white;
      border: 2px solid #EC4899;
      border-radius: 10px;
      padding: 20px;
      text-align: center;
      margin: 20px 0;
    }
    .code {
      font-size: 32px;
      font-weight: bold;
      letter-spacing: 8px;
      color: #EC4899;
      font-family: monospace;
    }
    .button {
      display: inline-block;
      background: #2563EB;
      color: white;
      padding: 12px 30px;
      text-decoration: none;
      border-radius: 8px;
      margin: 20px 0;
    }
    .footer {
      text-align: center;
      color: #666;
      font-size: 14px;
      margin-top: 30px;
      padding-top: 20px;
      border-top: 1px solid #ddd;
    }
  </style>
</head>
<body>
  <div class="header">
    <h1>Welcome to LendCircle!</h1>
  </div>
  <div class="content">
    <h2>Hi ${name},</h2>
    <p>Thank you for signing up with LendCircle. To complete your registration, please verify your email address using the code below:</p>
    
    <div class="code-box">
      <div class="code">${code}</div>
      <p style="color: #666; margin-top: 10px;">This code will expire in 10 minutes</p>
    </div>
    
    <p>If you didn't create an account with LendCircle, you can safely ignore this email.</p>
    
    <p>Best regards,<br>The LendCircle Team</p>
  </div>
  <div class="footer">
    <p>© ${new Date().getFullYear()} LendCircle. All rights reserved.</p>
    <p>This is an automated message, please do not reply.</p>
  </div>
</body>
</html>
    `;

    return this.sendEmail({
      to: email,
      subject: 'Verify Your Email - LendCircle',
      html,
      text: `Hi ${name}, Your verification code is: ${code}. This code will expire in 10 minutes.`
    });
  }

  // ============================================
  // 2FA CODE EMAIL
  // ============================================

  async send2FACode(email, name, code) {
    const html = `
<!DOCTYPE html>
<html>
<head>
  <style>
    body {
      font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
      line-height: 1.6;
      color: #333;
      max-width: 600px;
      margin: 0 auto;
      padding: 20px;
    }
    .header {
      background: #2563EB;
      color: white;
      padding: 30px;
      text-align: center;
      border-radius: 10px 10px 0 0;
    }
    .content {
      background: #f9f9f9;
      padding: 30px;
      border-radius: 0 0 10px 10px;
    }
    .code-box {
      background: white;
      border: 2px solid #2563EB;
      border-radius: 10px;
      padding: 20px;
      text-align: center;
      margin: 20px 0;
    }
    .code {
      font-size: 32px;
      font-weight: bold;
      letter-spacing: 8px;
      color: #2563EB;
      font-family: monospace;
    }
  </style>
</head>
<body>
  <div class="header">
    <h1>🔐 Two-Factor Authentication</h1>
  </div>
  <div class="content">
    <h2>Hi ${name},</h2>
    <p>A login attempt was made to your LendCircle account. Please use the code below to complete your login:</p>
    
    <div class="code-box">
      <div class="code">${code}</div>
      <p style="color: #666; margin-top: 10px;">This code will expire in 10 minutes</p>
    </div>
    
    <p><strong>If you didn't attempt to log in, please contact support immediately.</strong></p>
    
    <p>Best regards,<br>The LendCircle Team</p>
  </div>
</body>
</html>
    `;

    return this.sendEmail({
      to: email,
      subject: 'Your Login Code - LendCircle',
      html,
      text: `Hi ${name}, Your 2FA code is: ${code}. This code will expire in 10 minutes.`
    });
  }

  // ============================================
  // LOAN CONFIRMATION EMAIL
  // ============================================

  async sendLoanConfirmation(email, name, transaction) {
    const html = `
<!DOCTYPE html>
<html>
<head>
  <style>
    body {
      font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
      line-height: 1.6;
      color: #333;
      max-width: 600px;
      margin: 0 auto;
      padding: 20px;
    }
    .header {
      background: linear-gradient(135deg, #10B981, #2563EB);
      color: white;
      padding: 30px;
      text-align: center;
      border-radius: 10px 10px 0 0;
    }
    .content {
      background: #f9f9f9;
      padding: 30px;
      border-radius: 0 0 10px 10px;
    }
    .details {
      background: white;
      border: 1px solid #ddd;
      border-radius: 10px;
      padding: 20px;
      margin: 20px 0;
    }
    .detail-row {
      display: flex;
      justify-content: space-between;
      padding: 10px 0;
      border-bottom: 1px solid #eee;
    }
    .detail-row:last-child {
      border-bottom: none;
    }
    .detail-label {
      font-weight: 600;
      color: #666;
    }
    .detail-value {
      color: #333;
    }
    .amount {
      font-size: 28px;
      font-weight: bold;
      color: #10B981;
    }
  </style>
</head>
<body>
  <div class="header">
    <h1>✓ Loan Application Submitted</h1>
  </div>
  <div class="content">
    <h2>Hi ${name},</h2>
    <p>Your loan application has been successfully submitted and is now being processed.</p>
    
    <div class="details">
      <div class="detail-row">
        <span class="detail-label">Transaction ID:</span>
        <span class="detail-value">${transaction.transactionId}</span>
      </div>
      <div class="detail-row">
        <span class="detail-label">Amount:</span>
        <span class="detail-value amount">$${transaction.amount.toLocaleString()}</span>
      </div>
      <div class="detail-row">
        <span class="detail-label">Term:</span>
        <span class="detail-value">${transaction.term} months</span>
      </div>
      <div class="detail-row">
        <span class="detail-label">Interest Rate:</span>
        <span class="detail-value">${transaction.interestRate}% APR</span>
      </div>
      <div class="detail-row">
        <span class="detail-label">Status:</span>
        <span class="detail-value">${transaction.status.toUpperCase()}</span>
      </div>
    </div>
    
    <p>You will receive another email once your loan is matched with a borrower.</p>
    
    <p>Best regards,<br>The LendCircle Team</p>
  </div>
</body>
</html>
    `;

    return this.sendEmail({
      to: email,
      subject: `Loan Application Submitted - ${transaction.transactionId}`,
      html,
      text: `Your loan for $${transaction.amount} has been submitted. Transaction ID: ${transaction.transactionId}`
    });
  }

  // ============================================
  // VIP SERVICE ACTIVATION EMAIL
  // ============================================

  async sendVIPActivation(email, name) {
    const html = `
<!DOCTYPE html>
<html>
<head>
  <style>
    body {
      font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
      line-height: 1.6;
      color: #333;
      max-width: 600px;
      margin: 0 auto;
      padding: 20px;
    }
    .header {
      background: linear-gradient(135deg, #EC4899, #8B5CF6);
      color: white;
      padding: 30px;
      text-align: center;
      border-radius: 10px 10px 0 0;
    }
    .content {
      background: #f9f9f9;
      padding: 30px;
      border-radius: 0 0 10px 10px;
    }
    .vip-badge {
      background: linear-gradient(135deg, #EC4899, #8B5CF6);
      color: white;
      padding: 10px 20px;
      border-radius: 20px;
      display: inline-block;
      font-weight: bold;
      margin: 20px 0;
    }
  </style>
</head>
<body>
  <div class="header">
    <h1>◆ VIP Status Activated</h1>
  </div>
  <div class="content">
    <h2>Congratulations ${name}!</h2>
    
    <div class="vip-badge">◆ VIP MEMBER</div>
    
    <p>You have been upgraded to VIP status based on your lending activity.</p>
    
    <h3>VIP Benefits Include:</h3>
    <ul>
      <li>Priority borrower matching</li>
      <li>Enhanced privacy protections</li>
      <li>Dedicated account manager</li>
      <li>Premium interest rates (up to 15% APR)</li>
      <li>White-glove concierge service</li>
    </ul>
    
    <p><strong>Next Steps:</strong> A member of our VIP team will contact you within 24 hours via encrypted messaging (Signal/Telegram) to discuss your premium service options.</p>
    
    <p>Welcome to the VIP program,<br>The LendCircle VIP Team</p>
  </div>
</body>
</html>
    `;

    return this.sendEmail({
      to: email,
      subject: '◆ Welcome to VIP Status - LendCircle',
      html,
      text: `Congratulations! You've been upgraded to VIP status. Our team will contact you within 24 hours.`
    });
  }

  // ============================================
  // PASSWORD RESET EMAIL
  // ============================================

  async sendPasswordResetEmail(email, name, code) {
    const html = `
<!DOCTYPE html>
<html>
<head>
  <style>
    body {
      font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
      line-height: 1.6;
      color: #333;
      max-width: 600px;
      margin: 0 auto;
      padding: 20px;
    }
    .header {
      background: #EF4444;
      color: white;
      padding: 30px;
      text-align: center;
      border-radius: 10px 10px 0 0;
    }
    .content {
      background: #f9f9f9;
      padding: 30px;
      border-radius: 0 0 10px 10px;
    }
    .code-box {
      background: white;
      border: 2px solid #EF4444;
      border-radius: 10px;
      padding: 20px;
      text-align: center;
      margin: 20px 0;
    }
    .code {
      font-size: 32px;
      font-weight: bold;
      letter-spacing: 8px;
      color: #EF4444;
      font-family: monospace;
    }
  </style>
</head>
<body>
  <div class="header">
    <h1>Password Reset Request</h1>
  </div>
  <div class="content">
    <h2>Hi ${name},</h2>
    <p>We received a request to reset your password. Use the code below to reset your password:</p>
    
    <div class="code-box">
      <div class="code">${code}</div>
      <p style="color: #666; margin-top: 10px;">This code will expire in 30 minutes</p>
    </div>
    
    <p><strong>If you didn't request a password reset, please ignore this email and your password will remain unchanged.</strong></p>
    
    <p>Best regards,<br>The LendCircle Team</p>
  </div>
</body>
</html>
    `;

    return this.sendEmail({
      to: email,
      subject: 'Password Reset Request - LendCircle',
      html,
      text: `Your password reset code is: ${code}. This code will expire in 30 minutes.`
    });
  }
}

module.exports = new EmailService();
