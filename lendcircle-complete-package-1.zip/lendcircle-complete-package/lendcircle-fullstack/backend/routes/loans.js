const express = require('express');
const router = express.Router();
const Transaction = require('../models/Transaction');
const User = require('../models/User');
const { protect } = require('../middleware/auth');
const emailService = require('../utils/emailService');
const logger = require('../utils/logger');

// Protect all routes
router.use(protect);

// ============================================
// @route   POST /api/loans
// @desc    Create new loan
// @access  Private
// ============================================

router.post('/', async (req, res) => {
  try {
    const { amount, term, interestRate, borrowerType, anonymous, recurring } = req.body;

    // Validation
    if (!amount || !term || !interestRate) {
      return res.status(400).json({ 
        success: false, 
        message: 'Please provide amount, term, and interest rate' 
      });
    }

    // Create transaction
    const transaction = await Transaction.create({
      lender: req.user._id,
      type: 'lend',
      amount,
      term,
      interestRate,
      borrowerType: borrowerType || 'verified',
      anonymous: {
        enabled: anonymous || false
      },
      recurring: {
        enabled: recurring || false,
        dayOfWeek: new Date().getDay()
      },
      status: 'pending',
      fundedDate: new Date()
    });

    // Detect VIP signals
    const signals = transaction.detectVIPSignals();
    await transaction.save();

    // Update user portfolio
    await User.findByIdAndUpdate(req.user._id, {
      $inc: { 
        'portfolio.totalLent': amount,
        'portfolio.activeLoans': 1
      }
    });

    // Check if user should be flagged as VIP
    const user = await User.findById(req.user._id);
    const isVIPPattern = user.checkVIPPattern({
      amount,
      borrowerType,
      recurring,
      dayOfWeek: new Date().getDay()
    });
    
    if (isVIPPattern && !user.vipStatus.isVip) {
      await user.save();
      
      // Send VIP activation email
      try {
        await emailService.sendVIPActivation(user.email, user.name);
      } catch (error) {
        logger.error('VIP email failed:', error);
      }
    }

    // Send confirmation email
    try {
      await emailService.sendLoanConfirmation(user.email, user.name, transaction);
    } catch (error) {
      logger.error('Confirmation email failed:', error);
    }

    logger.info(`Loan created: ${transaction.transactionId} by user ${req.user.email}`);

    res.status(201).json({
      success: true,
      message: 'Loan application submitted successfully',
      transaction: {
        id: transaction._id,
        transactionId: transaction.transactionId,
        amount: transaction.amount,
        term: transaction.term,
        status: transaction.status,
        vipTransaction: transaction.vipTransaction
      },
      vipDetected: signals.length > 0
    });

  } catch (error) {
    logger.error('Loan creation error:', error);
    res.status(500).json({ 
      success: false, 
      message: 'Error creating loan' 
    });
  }
});

// ============================================
// @route   GET /api/loans
// @desc    Get all user's loans
// @access  Private
// ============================================

router.get('/', async (req, res) => {
  try {
    const loans = await Transaction.find({ 
      lender: req.user._id 
    }).sort({ createdAt: -1 });

    res.json({
      success: true,
      count: loans.length,
      data: loans
    });

  } catch (error) {
    logger.error('Get loans error:', error);
    res.status(500).json({ 
      success: false, 
      message: 'Error fetching loans' 
    });
  }
});

// ============================================
// @route   GET /api/loans/:id
// @desc    Get loan by ID
// @access  Private
// ============================================

router.get('/:id', async (req, res) => {
  try {
    const loan = await Transaction.findById(req.params.id);

    if (!loan) {
      return res.status(404).json({ 
        success: false, 
        message: 'Loan not found' 
      });
    }

    // Check ownership
    if (loan.lender.toString() !== req.user._id.toString() && req.user.role !== 'admin') {
      return res.status(403).json({ 
        success: false, 
        message: 'Not authorized to view this loan' 
      });
    }

    res.json({
      success: true,
      data: loan
    });

  } catch (error) {
    logger.error('Get loan error:', error);
    res.status(500).json({ 
      success: false, 
      message: 'Error fetching loan' 
    });
  }
});

module.exports = router;
