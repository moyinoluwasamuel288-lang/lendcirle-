const express = require('express');
const router = express.Router();
const { protect, authorize } = require('../middleware/auth');
const User = require('../models/User');
const Transaction = require('../models/Transaction');

router.use(protect);
router.use(authorize('admin'));

router.get('/dashboard', async (req, res) => {
  try {
    const stats = {
      totalUsers: await User.countDocuments(),
      totalLoans: await Transaction.countDocuments(),
      vipUsers: await User.countDocuments({ 'vipStatus.isVip': true }),
      totalVolume: await Transaction.aggregate([
        { $group: { _id: null, total: { $sum: '$amount' } } }
      ])
    };

    res.json({
      success: true,
      data: stats
    });
  } catch (error) {
    res.status(500).json({ success: false, message: 'Error fetching dashboard' });
  }
});

module.exports = router;
