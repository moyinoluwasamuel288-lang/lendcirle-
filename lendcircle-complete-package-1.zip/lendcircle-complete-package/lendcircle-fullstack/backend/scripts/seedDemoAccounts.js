const mongoose = require('mongoose');
const User = require('../models/User');
const Transaction = require('../models/Transaction');
require('dotenv').config();

const seedDatabase = async () => {
  try {
    // Connect to database
    await mongoose.connect(process.env.MONGODB_URI, {
      useNewUrlParser: true,
      useUnifiedTopology: true,
    });

    console.log('Connected to MongoDB');

    // Clear existing data (be careful in production!)
    if (process.env.NODE_ENV === 'development') {
      await User.deleteMany({});
      await Transaction.deleteMany({});
      console.log('Cleared existing data');
    }

    // Create demo users
    const demoUsers = [
      {
        name: 'Demo User',
        email: 'demo@lendcircle.com',
        password: 'demo1234',
        verified: true,
        role: 'user',
        vipStatus: {
          isVip: false,
          signalCount: 0
        }
      },
      {
        name: 'VIP User',
        email: 'vip@lendcircle.com',
        password: 'vip1234',
        verified: true,
        role: 'vip',
        vipStatus: {
          isVip: true,
          detectedAt: new Date(),
          signalCount: 5
        }
      },
      {
        name: 'Admin User',
        email: 'admin@lendcircle.com',
        password: 'admin123',
        verified: true,
        role: 'admin',
        vipStatus: {
          isVip: true,
          signalCount: 0
        }
      }
    ];

    const createdUsers = await User.create(demoUsers);
    console.log(`Created ${createdUsers.length} demo users`);

    // Create demo transactions for VIP user
    const vipUser = createdUsers.find(u => u.email === 'vip@lendcircle.com');
    
    const demoTransactions = [
      {
        lender: vipUser._id,
        type: 'lend',
        amount: 4999,
        term: 18,
        interestRate: 11,
        borrowerType: 'anonymous',
        status: 'vip',
        vipTransaction: true,
        fundedDate: new Date(),
        anonymous: {
          enabled: true
        },
        recurring: {
          enabled: true,
          dayOfWeek: 2
        }
      },
      {
        lender: vipUser._id,
        type: 'lend',
        amount: 4999,
        term: 18,
        interestRate: 11,
        borrowerType: 'anonymous',
        status: 'vip',
        vipTransaction: true,
        fundedDate: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000),
        anonymous: {
          enabled: true
        }
      }
    ];

    const createdTransactions = await Transaction.create(demoTransactions);
    console.log(`Created ${createdTransactions.length} demo transactions`);

    console.log('\n✓ Demo database seeded successfully!\n');
    console.log('Demo Accounts:');
    console.log('─────────────────────────────────────');
    console.log('Regular User:');
    console.log('  Email: demo@lendcircle.com');
    console.log('  Password: demo1234\n');
    console.log('VIP User:');
    console.log('  Email: vip@lendcircle.com');
    console.log('  Password: vip1234\n');
    console.log('Admin User:');
    console.log('  Email: admin@lendcircle.com');
    console.log('  Password: admin123\n');
    console.log('─────────────────────────────────────\n');

    process.exit(0);
  } catch (error) {
    console.error('Seeding error:', error);
    process.exit(1);
  }
};

seedDatabase();
