# 🚀 LendCircle - 5 Minute Quick Start

## For Complete Beginners

### Step 1: Install Prerequisites

**Install Node.js:**
- Go to https://nodejs.org/
- Download and install the LTS version (18.x or higher)
- Verify installation: Open terminal and type `node --version`

**Install MongoDB (Choose one):**

**Option A: MongoDB Atlas (Cloud - Recommended)**
1. Go to https://cloud.mongodb.com
2. Create free account
3. Create a free cluster (M0 Sandbox)
4. Click "Connect" → "Connect your application"
5. Copy the connection string
6. Replace `<password>` with your database password

**Option B: Local MongoDB**
- **macOS:** `brew install mongodb-community@6.0`
- **Windows:** Download from https://www.mongodb.com/try/download/community
- **Linux:** `sudo apt-get install mongodb`

### Step 2: Setup Project

```bash
# Navigate to backend folder
cd lendcircle-fullstack/backend

# Install all dependencies (this may take a few minutes)
npm install
```

### Step 3: Configure Environment

```bash
# Copy the example environment file
cp .env.example .env

# Open .env file in text editor
# On Mac: open .env
# On Windows: notepad .env
# On Linux: nano .env
```

**Edit `.env` file - Minimum required:**

```bash
NODE_ENV=development
PORT=5000
MONGODB_URI=mongodb://localhost:27017/lendcircle
# OR if using MongoDB Atlas:
# MONGODB_URI=mongodb+srv://username:password@cluster.mongodb.net/lendcircle

JWT_SECRET=your-super-secret-key-make-it-long-and-random-at-least-32-characters
FRONTEND_URL=http://localhost:3000

# Email (optional for testing - will show codes in console)
SMTP_EMAIL=your-email@gmail.com
SMTP_PASSWORD=your-app-password
```

### Step 4: Start Database (if using local MongoDB)

**macOS:**
```bash
brew services start mongodb-community@6.0
```

**Windows:**
```bash
# MongoDB should start automatically after installation
# Or start it from Services
```

**Linux:**
```bash
sudo systemctl start mongod
```

### Step 5: Seed Demo Data

```bash
npm run seed
```

This creates 3 demo accounts:
- `demo@lendcircle.com` / `demo1234`
- `vip@lendcircle.com` / `vip1234`
- `admin@lendcircle.com` / `admin123`

### Step 6: Start Server

```bash
npm run dev
```

You should see:
```
╔════════════════════════════════════════╗
║     LendCircle Backend Server         ║
║     Environment: development          ║
║     Port: 5000                        ║
╚════════════════════════════════════════╝
```

### Step 7: Test API

Open a new terminal window and test:

```bash
# Test health endpoint
curl http://localhost:5000/health

# Test registration
curl -X POST http://localhost:5000/api/auth/register \
  -H "Content-Type: application/json" \
  -d '{"name":"Test User","email":"test@test.com","password":"password123"}'
```

### Step 8: Connect Frontend

Use the HTML frontend file provided, or connect your own React app to:
- **API Base URL:** `http://localhost:5000/api`

## 🎉 You're Done!

Your backend is now running at **http://localhost:5000**

## Common Issues

**"Port 5000 already in use"**
- Change `PORT=5001` in `.env` file

**"Cannot connect to MongoDB"**
- If using local MongoDB: `sudo systemctl start mongod`
- If using Atlas: Check your connection string and password

**"Email not sending"**
- This is OK for development! Codes will show in console
- To enable emails, add Gmail credentials to `.env`

## Next Steps

1. Open the HTML frontend file in your browser
2. Click a demo account to login
3. Start testing the platform!

## Need Help?

1. Check `logs/app.log` for errors
2. Make sure MongoDB is running
3. Verify `.env` file has correct settings
4. Check that port 5000 is not in use

---

**Backend is ready! Now use the HTML file to interact with it.**
