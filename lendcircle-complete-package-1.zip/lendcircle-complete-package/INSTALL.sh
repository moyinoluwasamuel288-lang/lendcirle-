#!/bin/bash

echo "╔════════════════════════════════════════════╗"
echo "║     LendCircle Quick Install Script       ║"
echo "╚════════════════════════════════════════════╝"
echo ""

# Check if Node.js is installed
if ! command -v node &> /dev/null; then
    echo "❌ Node.js is not installed!"
    echo "📥 Please install Node.js from: https://nodejs.org/"
    echo ""
    exit 1
fi

echo "✓ Node.js found: $(node --version)"
echo ""

# Check if npm is installed
if ! command -v npm &> /dev/null; then
    echo "❌ npm is not installed!"
    exit 1
fi

echo "✓ npm found: $(npm --version)"
echo ""

# Ask which version to install
echo "Which version do you want to install?"
echo "1) MVP (Quick test - 60 seconds)"
echo "2) Full-Stack (Production version)"
echo ""
read -p "Enter choice (1 or 2): " choice

if [ "$choice" = "1" ]; then
    echo ""
    echo "Installing MVP..."
    cd lendcircle-mvp
    npm install
    echo ""
    echo "✓ MVP installed successfully!"
    echo ""
    echo "To start the server, run:"
    echo "  cd lendcircle-mvp"
    echo "  npm start"
    echo ""
elif [ "$choice" = "2" ]; then
    echo ""
    echo "Installing Full-Stack..."
    cd lendcircle-fullstack/backend
    npm install
    echo ""
    echo "✓ Full-Stack installed successfully!"
    echo ""
    echo "Next steps:"
    echo "  1. Copy .env.example to .env"
    echo "  2. Configure your MongoDB connection"
    echo "  3. Run: npm run seed"
    echo "  4. Run: npm start"
    echo ""
    echo "See QUICKSTART.md for detailed instructions."
else
    echo "Invalid choice. Exiting."
    exit 1
fi

echo "Done! 🎉"
