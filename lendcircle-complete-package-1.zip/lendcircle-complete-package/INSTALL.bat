@echo off
echo ╔════════════════════════════════════════════╗
echo ║     LendCircle Quick Install Script       ║
echo ╚════════════════════════════════════════════╝
echo.

REM Check if Node.js is installed
where node >nul 2>nul
if %errorlevel% neq 0 (
    echo ❌ Node.js is not installed!
    echo 📥 Please install Node.js from: https://nodejs.org/
    echo.
    pause
    exit /b 1
)

echo ✓ Node.js found
node --version
echo.

REM Ask which version
echo Which version do you want to install?
echo 1) MVP (Quick test - 60 seconds)
echo 2) Full-Stack (Production version)
echo.
set /p choice="Enter choice (1 or 2): "

if "%choice%"=="1" (
    echo.
    echo Installing MVP...
    cd lendcircle-mvp
    call npm install
    echo.
    echo ✓ MVP installed successfully!
    echo.
    echo To start the server, run:
    echo   cd lendcircle-mvp
    echo   npm start
    echo.
) else if "%choice%"=="2" (
    echo.
    echo Installing Full-Stack...
    cd lendcircle-fullstack\backend
    call npm install
    echo.
    echo ✓ Full-Stack installed successfully!
    echo.
    echo Next steps:
    echo   1. Copy .env.example to .env
    echo   2. Configure your MongoDB connection
    echo   3. Run: npm run seed
    echo   4. Run: npm start
    echo.
) else (
    echo Invalid choice. Exiting.
    exit /b 1
)

echo Done! 🎉
pause
